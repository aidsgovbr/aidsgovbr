(function ($) {
	// Cookie Functions - Start
	$(document).ready(function () {
				
	    $('#wrapper-footer-brasil').wrap("<div class='container'></div>");
	        
		
	});
	// Class manipulation based on cookie check - end
	

	//Close behaviors	
})(jQuery);
