clusterer
=========

Evolution of Jef Poskanzer Clusterer for Google Maps API V3 compliance