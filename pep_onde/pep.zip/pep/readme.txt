http://www.convertcsv.com/csv-to-json.htm
http://www.convertcsv.com/csv-viewer-editor.htm

http://csvlint.io/
http://codebeautify.org/csv-to-xml-json
http://www.csvjson.com/csv2json

Instructions 

1. copy paste into docs.google.com
2. validate csv http://csvlint.io/
3. copy and replace table headings
4. add estados full names
